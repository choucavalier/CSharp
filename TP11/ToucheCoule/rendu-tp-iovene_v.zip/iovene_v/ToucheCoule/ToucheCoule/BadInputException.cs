﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToucheCoule
{
    class BadInputException /* Something should be here, or maybe not */
    {
        //FIX ME
    }
}
