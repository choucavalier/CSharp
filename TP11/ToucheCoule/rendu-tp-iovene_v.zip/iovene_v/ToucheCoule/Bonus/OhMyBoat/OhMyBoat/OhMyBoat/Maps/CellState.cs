﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OhMyBoat.Maps
{
    enum CellState
    {
        WaterHidden,
        Water,
        BoatHidden,
        BoatBurning,
        BoatDestroyed
    }
}
